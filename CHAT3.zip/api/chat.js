// api/chat.js
import express from "express";
import OpenAI from "openai";
import dotenv from "dotenv";
dotenv.config();

const router = express.Router();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

router.post("/chat", async (req, res) => {
  const { messages } = req.body;

  const chatHistory = messages.map((m) => ({
    role: m.from === "user" ? "user" : "assistant",
    content: m.text,
  }));

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5",
      messages: [
        {
          role: "system",
          content:
            "Você é um amigo divertido e inteligente que ajuda a planejar viagens com sugestões de paradas, hospedagens e comidas incríveis. Fale sempre em português brasileiro, de forma leve e descontraída.",
        },
        ...chatHistory,
      ],
      temperature: 0.8,
    });

    const reply = response.choices[0].message.content;
    res.json({ reply });
  } catch (error) {
    console.error("Erro ao chamar o ChatGPT:"+ error);
    res.status(500).json({ reply:+ " Deu ruim aqui 😅 Tenta de novo depois!" });
  }
});

export default router;
